//
//  SZActionButton+Private.h
//  Socialize
//
//  Created by Nathaniel Griswold on 6/23/12.
//  Copyright (c) 2012 Socialize. All rights reserved.
//

#import "SZActionButton.h"

@interface SZActionButton ()

- (void)handleButtonPress:(id)sender;
- (void)configureButtonBackgroundImages;

@end

