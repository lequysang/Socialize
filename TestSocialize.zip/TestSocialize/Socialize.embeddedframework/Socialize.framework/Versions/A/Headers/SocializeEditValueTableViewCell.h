//
//  EditValueTableViewCell.h
//  appbuildr
//
//  Created by William Johnson on 1/11/11.
//  Copyright 2011 pointabout. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SocializeEditValueTableViewCell : UITableViewCell 
{

	
}

@end
