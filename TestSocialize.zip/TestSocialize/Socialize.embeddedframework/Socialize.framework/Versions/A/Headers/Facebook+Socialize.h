//
//  Facebook+Socialize.h
//  Socialize
//
//  Created by Nathaniel Griswold on 8/7/12.
//  Copyright (c) 2012 Socialize. All rights reserved.
//

#import <FBConnect/FBConnect.h>

@interface Facebook (Socialize)

- (BOOL)isForCurrentSocializeSession;

@end
