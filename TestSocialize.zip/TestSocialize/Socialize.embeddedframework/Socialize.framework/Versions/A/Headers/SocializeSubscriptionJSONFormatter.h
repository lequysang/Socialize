//
//  SocializeSubscriptionJSONFormatter.h
//  SocializeSDK
//
//  Created by Nathaniel Griswold on 12/14/11.
//  Copyright (c) 2011 Socialize, Inc. All rights reserved.
//

#import "SocializeObjectJSONFormatter.h"

@interface SocializeSubscriptionJSONFormatter : SocializeObjectJSONFormatter

@end
