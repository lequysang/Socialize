//
//  SocializeShareJSONFormatter.h
//  SocializeSDK
//
//  Created by Fawad Haider on 7/1/11.
//  Copyright 2011 Socialize, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SocializeCommentJSONFormatter.h"


@interface SocializeShareJSONFormatter : SocializeCommentJSONFormatter {
    
}

@end
