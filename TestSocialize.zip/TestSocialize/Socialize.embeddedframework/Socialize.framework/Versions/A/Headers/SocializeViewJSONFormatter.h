//
//  SocializeViewJSONFormatter.h
//  SocializeSDK
//
//  Created by Fawad Haider on 6/30/11.
//  Copyright 2011 Socialize, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SocializeActivityJSONFormatter.h"


@interface SocializeViewJSONFormatter : SocializeActivityJSONFormatter {
    
}

@end
