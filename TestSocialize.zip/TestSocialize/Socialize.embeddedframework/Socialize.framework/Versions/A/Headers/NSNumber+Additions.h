//
//  NSNumber+Additions.h
//  appbuildr
//
//  Created by Fawad Haider  on 2/16/11.
//  Copyright 2011 pointabout. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface  NSNumber(SocializeFormattingExtension)
+(NSString*)formatMyNumber:(NSNumber*)mynumber ceiling:(NSNumber*)ceilingg;
@end
