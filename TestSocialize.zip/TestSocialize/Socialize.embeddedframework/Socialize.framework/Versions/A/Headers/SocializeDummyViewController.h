//
//  SocializeDummyViewController.h
//  SocializeSDK
//
//  Created by Nathaniel Griswold on 3/26/12.
//  Copyright (c) 2012 Socialize, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SocializeBaseViewController.h"

@interface SocializeDummyViewController : SocializeBaseViewController

@end
