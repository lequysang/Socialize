//
//  SocializeDeviceTokenJSONFormatter.h
//  SocializeSDK
//
//  Created by Isaac Mosquera on 12/12/11.
//  Copyright (c) 2011 Socialize, Inc. All rights reserved.
//

#import "SocializeObjectJSONFormatter.h"
@interface SocializeDeviceTokenJSONFormatter : SocializeObjectJSONFormatter

@end
