//
//  POOCObjectFactory.h
//  SocializeSDK
//
//  Created by William Johnson on 5/17/11.
//  Copyright 2011 Socialize, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SocializeObjectFactory.h"


@interface SocializePOOCObjectFactory : SocializeObjectFactory 
{

}

@end
