//
//  SZLikeOptions.h
//  SocializeSDK
//
//  Created by Nathaniel Griswold on 6/3/12.
//  Copyright (c) 2012 Socialize, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SZActivityOptions.h"

@interface SZLikeOptions : SZActivityOptions

@end
