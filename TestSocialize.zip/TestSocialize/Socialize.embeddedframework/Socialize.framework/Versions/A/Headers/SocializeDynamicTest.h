//
//  SocializeDynamicTest.h
//  SocializeSDK
//
//  Created by Nathaniel Griswold on 11/28/11.
//  Copyright (c) 2011 Socialize, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SocializeDynamicTest : NSObject

@end
