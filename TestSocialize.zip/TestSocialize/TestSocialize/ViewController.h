//
//  ViewController.h
//  TestSocialize
//
//  Created by Sang Quý Lê on 4/8/13.
//  Copyright (c) 2013 lequysang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Socialize/Socialize.h>
#import "GADBannerView.h"

@interface ViewController : UIViewController<GADBannerViewDelegate>
@property (nonatomic, strong) SZActionBar *actionBar;
@property (nonatomic, weak) id<SZEntity> entity;

@property (strong,nonatomic) GADBannerView *bannerView;
- (GADRequest *)createRequest;

@end
